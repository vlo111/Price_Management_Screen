select 
'insert into CustomerContact (CustomerID, First, Last) select ' + cast([Customer ID] as varchar) + ', ''' + 
case when [First Name] = '' then 'Unknown' else isnull(rtrim(dbo.[fn_npclean_string](replace([First Name], '''', ''))), 'Unknown') end + ''', ''' + 
case when [Last Name] = '' then 'Unknown' else isnull(rtrim(dbo.[fn_npclean_string](replace([Last Name], '''', ''))), 'Unknown') end + ''''
from tempCustomerImport where [First Name] is not null or [Last Name] is not null

select 
'insert into CustomerContact (CustomerID, First, Last, JobTitle) select ' + cast([Customer ID] as varchar) + ', ''' + 
SUBSTRING(salesperson, 1, CHARINDEX(' ', salesperson) - 1) + ''', ''' + 
SUBSTRING(salesperson, CHARINDEX(' ', salesperson) + 1, 8000) + ''', ''Salesperson'''
from tempCustomerImport where salesperson is not null

select
'select @CustomerContactID = min(CustomerContactID) from CustomerContact where CustomerID = ' + cast([Customer ID] as varchar) + ';' +
'insert into ContactInfo select @type1, @CustomerContactID, ''Cell'', ''' + case when len(Cell) > 8 then Cell else [Area Code] + '-' + Cell end + ''', ''false'';'
from tempCustomerImport where Cell is not null

select
'select @CustomerContactID = min(CustomerContactID) from CustomerContact where CustomerID = ' + cast([Customer ID] as varchar) + ';' +
'insert into ContactInfo select @type2, @CustomerContactID, ''Email'', ''' + [Email Address] + ''', ''false'';'
from tempCustomerImport where [Email Address] is not null

select
'update Customer set Packaging = ' + cast(Packaging * 100 as varchar) + ', ShipCharges = ''' + 
case when ShipCharges is null then 'None' when ShipCharges = 'COLLECT' then 'Collect' else 'Prepaid' end +
''' where CustomerID = ' + cast([Customer ID] as varchar)  from tempCustomerImport

select distinct 'insert into Carrier (CarrierName, City) select ''' + rtrim(Carrier) + ''', ''Unknown''' from tempCustomerImport where Carrier is not null

select 'insert into CustomerCarrier (CustomerCarrierID, CustomerID, CarrierID) select @i, ' + cast([Customer ID] as varchar) + ', (select CarrierID from Carrier where CarrierName = ''' +
rtrim(Carrier) + '''); set @i = @i + 1;' from tempCustomerImport where Carrier is not null