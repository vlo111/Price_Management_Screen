select * from tempCustomerImport
--select distinct packaging from tempCustomerImport
--select distinct carrier from tempCustomerImport
--select distinct shipcharges from tempCustomerImport
--select packaging from tempCustomerImport where packaging > 0
--select shipcharges from tempCustomerImport where shipcharges is not null
--select salesperson from tempCustomerImport where salesperson is not null
--select distinct Cell from tempCustomerImport
--delete from tempCustomerImport where [Customer ID] = 3242
--select rtrim(dbo.[fn_npclean_string]([Last Name])) from tempCustomerImport where [Last Name] like '% %'
/*
select len([Email Address]), [Customer ID], [Email Address] from tempCustomerImport where [Email Address] is not null and 
([Email Address] like '% %' or [Email Address] like '%,%' or [Email Address] like '%;%') order by len([Email Address]) desc
begin transaction
update tempCustomerImport set [Email Address] = 'accounting@allseasondecking.net-invoices Nancy,conf-admin@allseasondecking.net-Kara,Daniel-sales@allseasondecking.net,Jason-jason@allseasondecking.net' where [Customer ID] = 2818
rollback;
*/

select * from Customer
select * from Carrier

CREATE function [dbo].[fn_npclean_string] (
 @strIn as varchar(1000)
)
returns varchar(1000)
as
begin
 declare @iPtr as int
 set @iPtr = patindex('%[^ -~0-9A-Z]%', @strIn COLLATE LATIN1_GENERAL_BIN)
 while @iPtr > 0 begin
  set @strIn = replace(@strIn COLLATE LATIN1_GENERAL_BIN, substring(@strIn, @iPtr, 1), '')
  set @iPtr = patindex('%[^ -~0-9A-Z]%', @strIn COLLATE LATIN1_GENERAL_BIN)
 end
 return @strIn
end   